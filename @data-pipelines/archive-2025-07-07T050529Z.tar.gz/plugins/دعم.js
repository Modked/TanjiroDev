let handler = async m => m.reply(`

≡  *𝙎𝙖𝙨𝙪𝙠𝙚-Bot-MD*

_*قــنــاة*:_
─────────────
▢ *قـنـاة الــدعـم_(AR🇾🇪)*
https://whatsapp.com/channel/0029VaklBGFHFxOwODjsoP13
_*تــنــورونــا 🥰🎀*_
`.trim())
handler.help = ['gpflash']
handler.tags = ['main']
handler.command = ['group', 'support','الدعم','دعم']

export default handler